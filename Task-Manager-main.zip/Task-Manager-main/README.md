# [Task-Manager](https://task-manager-z8t7.onrender.com/index.html)

## Project Setup

In order to run the project, setup .env and set MONGO_URI variable equal to DB connection string.

In order to avoid port collisions, in the source code port value is 5000
